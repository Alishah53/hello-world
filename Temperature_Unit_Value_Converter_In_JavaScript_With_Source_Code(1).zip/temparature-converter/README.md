Temparature Converter Converts the given temparature into other units.
Also some common temparature reference points are also added

<img src="./temparature-converter.gif" alt="temparature-converter.gif" />

